
 function myFunction() {

 

 var x = document.forms["csiform"]["fname"];
    if (x.value == "") {
        alert("FName should not be blank !!");
        return false;
    }

	if (! allLetter(x)) {
		 alert("First Name should be all characters!!");
		 return false;
	}
var a = document.forms["csiform"]["lname"];
    if (a.value == "") {
        alert("last name should not be blank !!");
        return false;
    }

	if (! allLetter(a)) {
		 alert("lName should be all characters!!");
		 return false;
	}
	



var y = document.forms["csiform"]["num"];

  if (y.value == "") {
                alert("Contact No. should not be blank !!");
		            
		return false;
            }

	if (! allnumeric(y)) {
		 alert('Please input numeric characters only');
      return false;
	}
	/*if(y.length<10)
	/{
		alert('Please Enter a valid number');
		return false;
	}*/

var z = document.forms["csiform"]["em"];

  if (z.value == "") {
                alert("Email should not be blank !!");
		            
		return false;
            }

	if (! ValidateEmail(z)) {
		 alert('Please input valid Email ID!!!');
      return false;
	}


var t = document.forms["csiform"]["dept"];


	
	if (deptselect(t)) {
		 alert('Please select a department!');
      return false;
	}
var d = document.forms["csiform"]["year"];


	
	if (year(d)) {
		 alert('Please select a year!');
      return false;
	}
var c = document.forms["csiform"]["id"];


	
	if (c.length<10) {
		 alert('Please enter a valid 10 digit student id');
      return false;
	}



 }






            function allLetter(inputtxt)
                {
                 var letters = /^[A-Za-z]+$/;
                 if(inputtxt.value.match(letters))
                   {
              	     return true;
                   }
                 else
                   {
              	     return false;
                   }
                }


            function allnumeric(inputtxt)
               {
                  var numbers = /^[0-9]+$/;
                  if(inputtxt.value.match(numbers))
                  {
                    return true;
                  }
                  else
                  {
                    return false;
                  }
               }

  

            function limit(element,limit)
              {
                var max_chars = limit;

                  if(element.value.length > max_chars) {
                    element.value = element.value.substr(0, max_chars);
                  }
              }

			
			 
			function ValidateEmail(inputText)
			 {
				var mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
				if(inputText.value.match(mailformat))
					{
					
					return true;
					}
				else
					{
					return false;
					}
			}

			function deptselect(dept)
				{
					
					if(dept.value == "no")
					{
						 alert('please select a department');
						return false;
					}
					else
					{
						 alert('yes');
						return true;
					}
				}
			function year(year)
				{
					
					if(year.value == "no")
					{
						 alert('please select a year');
						return false;
					}
					else
					{
						 alert('yes');
						return true;
					}
				}