STEP1:
Run : "localhost/connect.php"
on the search window of your browser.

STEP2:
Run:
"localhost/csi.html"
on your browser. This will redirect you to the form. 

STEP3:
The first window is to make a new Entry in the Resprctive Table.
 And Second one is for retrieving the stored Data.