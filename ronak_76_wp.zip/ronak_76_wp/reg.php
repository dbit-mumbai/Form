<?php
$fn=$_GET["fname"];
$mn=$_GET["mname"];
$ln=$_GET["lname"];

$a=$_GET["dob"];
echo $a;
echo "<BR>";



$dob=$_GET["dob"];
$gen=$_GET["gen"];
$num=$_GET["num"];

$em=$_GET["em"];
$addr=$_GET["addr"];
$ct=$_GET["ct"];

$dept=$_GET["dept"];
$yr=$_GET["yr"];
$id=$_GET["id"];

$skl=$_GET["skl"];
$additional=$_GET["additional"];
$amt=$_GET["amt"];



echo "Fname: ".$fn;
echo "<br>";
echo "Mname: ".$mn;
echo "<br>";
echo "Lname: ".$ln;
echo "<br>";
echo "Gender: ".$gen;
echo "<br>";
echo "Contact: ".$num;
echo "<br>";
echo "Email: ".$em;
echo "<br>";
echo "Address: ".$addr;
echo "<br>";
echo "City: ".$ct;
echo "<br>";
echo "Department: ".$dept;
echo "<br>";
echo "Class: ".$yr;
echo "<br>";
echo "CSI ID: ".$id;
echo "<br>";

/*
echo "Skill: ".$_GET["skl[0]"];
echo "Skill: ".$_GET["skl[1]"];
echo "Skill: ".$_GET["skl[2]"];
echo "Skill: ".$_GET["skl[3]"];
echo "Skill: ".$_GET["skl[4]"];
echo "Skill: ".$_GET["skl[5]"];
*/

$name="";
foreach ($skl as $i){
echo $i."<br />";
$name=$name.",".$i;
}
echo "name=".$name;
echo "<br>";
echo "Additional skill: ".$additional;
echo "<br>";

/*
echo "dmem: ".$_GET["dmem"];
echo "<br>";
echo "imem: ".$_GET["imem"];
echo "<br>";
*/
echo "amt: ".$amt;
echo "<br>";


include "connect.php";

$sql = "INSERT INTO membership VALUES('$fn','$mn','$ln','$gen','$num','$em','$addr','$ct','$dept','$yr','$id','$name','$additional','$amt')";
      
		$result = mysqli_query($con,$sql);


?>


