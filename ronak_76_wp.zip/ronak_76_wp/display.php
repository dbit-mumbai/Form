<?php

include "connect.php";
$sql = "select * from membership";

$result = $con->query($sql);
if ($result->num_rows > 0) {
    // output data of each row
	$i=0;
    while($row = $result->fetch_assoc()) {
        echo "id: ".$i." First name=". $row["fn"]. " Middle Name: " . $row["mn"]. " Last Name " . $row["ln"]. "<br>";
		$i++;
    }
} else {
    echo "0 results";
}
$con->close();

?>